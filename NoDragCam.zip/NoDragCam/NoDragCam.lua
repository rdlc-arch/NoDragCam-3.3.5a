-- NoDragCam 1.4 (WotLK 3.3.5a)
-- Camera turn speeds are kept at 0 BY DEFAULT, so a tap or left-drag can't
-- rotate the camera even on the very first frame (touch taps warp the cursor
-- in the same frame as the press, which is too fast to react to).
-- Speeds are restored only while you steer: right mouse button held, or
-- mouselook without the left button (e.g. the Move and Steer keybind).

local CV_YAW, CV_PITCH = "cameraYawMoveSpeed", "cameraPitchMoveSpeed"
local DEFAULT_YAW, DEFAULT_PITCH = "180", "90"

local db
local suppressed = false
local f = CreateFrame("Frame", "NoDragCamFrame")

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99NoDragCam|r: " .. msg)
end

local MOD_CHECK = {
    alt   = IsAltKeyDown,
    ctrl  = IsControlKeyDown,
    shift = IsShiftKeyDown,
}

-- The game may refuse 0 or something may reset the value, so we re-check
-- every frame and fall back to the lowest value the client accepts.
local TRY = { "0", "0.001", "0.01", "0.1", "1" }
local low = {}     -- per CVar: lowest value that actually stuck
local lowNote = {} -- for /ndc status

local function ForceLow(cv, key)
    if lowNote[cv] and lowNote[cv]:find("REFUSED") then return end -- don't spam every frame
    local cur = tonumber(GetCVar(cv))
    local target = low[cv]
    if target and cur == tonumber(target) then return end
    -- remember the real speed (anything above our low values)
    if cur and cur > 1 then db[key] = GetCVar(cv) end
    if target then
        SetCVar(cv, target)
        if tonumber(GetCVar(cv)) == tonumber(target) then return end
    end
    for _, v in ipairs(TRY) do
        SetCVar(cv, v)
        if tonumber(GetCVar(cv)) == tonumber(v) then
            low[cv] = v
            lowNote[cv] = v
            return
        end
    end
    lowNote[cv] = "REFUSED (stays " .. tostring(GetCVar(cv)) .. ")"
end

local function Suppress()
    db.pending = true
    ForceLow(CV_YAW, "yaw")
    ForceLow(CV_PITCH, "pitch")
    suppressed = true
end

local function Restore(force)
    if not suppressed and not force then return end
    SetCVar(CV_YAW, db.yaw or DEFAULT_YAW)
    SetCVar(CV_PITCH, db.pitch or DEFAULT_PITCH)
    db.pending = nil
    suppressed = false
end

-- Track the Move and Steer keybind directly instead of guessing from
-- IsMouselooking(), which a held touch can also trigger.
local steering = false
if MoveAndSteerStart then hooksecurefunc("MoveAndSteerStart", function() steering = true end) end
if MoveAndSteerStop then hooksecurefunc("MoveAndSteerStop", function() steering = false end) end

-- Keyboard/controller camera turning (MoveViewUp/Down/Left/Right) uses the same
-- speed CVars, so it must get the real speeds too. This covers CameraPitch and
-- any other addon or binding that calls these functions.
local viewKeys = {}
local function ViewKeysActive()
    for _, on in pairs(viewKeys) do if on then return true end end
    return false
end
for _, dir in ipairs({ "Up", "Down", "Left", "Right" }) do
    local d = dir
    if _G["MoveView" .. d .. "Start"] then
        hooksecurefunc("MoveView" .. d .. "Start", function()
            viewKeys[d] = true
            if db then Restore() end -- same frame, so it starts at full speed
        end)
    end
    if _G["MoveView" .. d .. "Stop"] then
        hooksecurefunc("MoveView" .. d .. "Stop", function() viewKeys[d] = false end)
    end
end

local function WantsCamera()
    if IsMouseButtonDown("RightButton") then return true, "right" end -- right-drag / both buttons
    if steering then return true, "steer" end                          -- Move and Steer key
    if ViewKeysActive() then return true, "viewkey" end               -- camera look/pan keybinds
    if db.mod ~= "none" and MOD_CHECK[db.mod] and MOD_CHECK[db.mod]() then return true, "mod" end
    return false, "blocked"
end

local lastDebug
local function OnUpdate()
    local want, why = WantsCamera()
    if not db.enabled then want, why = true, "off" end
    if want then Restore() else Suppress() end
    if db.debug then
        local line = ("L=%s R=%s look=%s steer=%s -> %s (yaw=%s)"):format(
            IsMouseButtonDown("LeftButton") and 1 or 0,
            IsMouseButtonDown("RightButton") and 1 or 0,
            IsMouselooking() and 1 or 0, (steering or ViewKeysActive()) and 1 or 0,
            why, GetCVar(CV_YAW))
        if line ~= lastDebug then Print(line); lastDebug = line end
    end
end

f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGOUT")
f:SetScript("OnEvent", function(self, event, name)
    if event == "ADDON_LOADED" and name == "NoDragCam" then
        NoDragCamDB = NoDragCamDB or {}
        db = NoDragCamDB
        if db.enabled == nil then db.enabled = true end
        db.mod = db.mod or "none"
        -- if speeds were left at 0 last session, put them back first
        if db.pending or (tonumber(GetCVar(CV_YAW)) or 0) <= 1 then Restore(true) end
        self:SetScript("OnUpdate", OnUpdate)
        self:UnregisterEvent("ADDON_LOADED")
    elseif event == "PLAYER_LOGOUT" then
        Restore()
    end
end)

SLASH_NODRAGCAM1 = "/ndc"
SLASH_NODRAGCAM2 = "/nodragcam"
SlashCmdList["NODRAGCAM"] = function(msg)
    msg = (msg or ""):lower():match("^%s*(.-)%s*$")
    local cmd, arg = msg:match("^(%S*)%s*(.*)$")
    if cmd == "" or cmd == "toggle" then
        db.enabled = not db.enabled
        if not db.enabled then Restore() end
        Print(db.enabled and "ON - tap/left-drag camera disabled" or "OFF - normal camera")
    elseif cmd == "on" then
        db.enabled = true; Print("ON")
    elseif cmd == "off" then
        db.enabled = false; Restore(); Print("OFF")
    elseif cmd == "mod" and (arg == "alt" or arg == "ctrl" or arg == "shift" or arg == "none") then
        db.mod = arg
        Print(arg == "none" and "No bypass modifier" or ("Hold " .. arg:upper() .. " to rotate normally"))
    elseif cmd == "status" then
        Print(("enabled=%s  yaw=%s  pitch=%s  saved=%s/%s"):format(
            tostring(db.enabled), GetCVar(CV_YAW), GetCVar(CV_PITCH),
            tostring(db.yaw), tostring(db.pitch)))
        Print(("lowest accepted: yaw=%s  pitch=%s"):format(
            tostring(lowNote[CV_YAW] or "not tried yet"),
            tostring(lowNote[CV_PITCH] or "not tried yet")))
    elseif cmd == "debug" then
        db.debug = not db.debug
        Print("debug " .. (db.debug and "ON - prints what it sees on every change" or "OFF"))
    elseif cmd == "reset" then
        db.yaw, db.pitch = DEFAULT_YAW, DEFAULT_PITCH
        Restore(true)
        Print("Camera speeds reset to defaults")
    else
        Print("/ndc - toggle | /ndc on|off | /ndc status | /ndc debug | /ndc mod alt|ctrl|shift|none | /ndc reset")
    end
end
